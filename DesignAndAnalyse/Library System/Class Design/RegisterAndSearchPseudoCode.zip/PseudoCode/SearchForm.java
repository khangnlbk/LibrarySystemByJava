class SearchForm {

/**
* Enter keyword when searching
* @return the keyword that has already entered
*/
  public String enterKeyword() {
    Input the keyword
    Set input to the keyword
    return input
  }

/**
* Implement searching by call to method searchBook in SearchController
*/
  public void search() {
    SearchController sc
    Set input equal to the result of enterKeyword()
    call sc.searchBook(input)
  }
}
