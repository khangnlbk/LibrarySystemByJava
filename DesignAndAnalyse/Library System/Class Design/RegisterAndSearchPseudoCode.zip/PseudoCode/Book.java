class Book {
  private String bookNumber;
  private String title;
  private String author;
  private String publisher;
  private String isbn;
  private ArrayList<Copy> copyList;

  public String getBookNumber() { return bookNumber; }
  public String getTitle() { return title; }
  public String getAuthor() { return author; }
  public String getPublisher() { return publisher; }
  public String getIsbn() { return isbn; }
  public ArrayList<Copy> getCopyInfor() { return copyList; }

/**
* Display the book's information including its copy's information
*/
  public void displayBookInformation() {
    getBookNumber() + getTitle() + getAuthor() + getPublisher() + getIsbn() +
      getCopyList();
  }
}
