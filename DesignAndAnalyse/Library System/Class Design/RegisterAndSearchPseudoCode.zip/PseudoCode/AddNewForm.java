class AddNewForm {

/**
* Enter the information for the book that want to create new in database
* @param the book that want to add new to database
*/
  public void enterInformation(Book book) {
    AddNewController anc
    Input the data for book
    Input the data for copy
    call anc.validateInput(book)
    call anc.validateInput(copy)
  }

/**
* Enter the information for the copy that want to create new in database
* @param the copy that want to add new to database
*/
  public void enterInformation(Copy copy) {
    AddNewController anc
    Input the data for copy
    call anc.validateInput(copy)
  }
}
