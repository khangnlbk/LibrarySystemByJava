class AddNewController {

/**
* Add the new book and its copy information to database
* @param the book's information
* @param the its copy's information
*/
  public void addNew(Book book, Copy copy) {
    add to database with book and copy
  }

/**
* Generate the next copy number following the existed copy number of the chosen book
* @param the book that is chosen
* @return the next copy number of the chosen book
*/
  public String generateCopyNumber(Book book) {
    Set copylist to book.getCopyList
    Set lastCopy to copylist.last
    generate the number following lastCopy.getCopyNumber
    return number
  }

/**
* Generate the book number following the form of system (XX9999, XX: classification,
* 9999: 4 bytes starting from 1 of each classification)
* @return the book number after generating
*/
  public String generateBookNumber() {
    generate the book number following the classification
    return number
  }

/**
* Check the input data of the book if it's right data, if the return is true,
* the data is correct, else the data is incorrect
* @param the book information
* @return the result of the test: true/false
*/
  public boolean validateInput(Book book) {
    check all the field of book if they are the String variable
    call validateInput(copy) to check the input of the first copy
    if one field is incorrect then
      return false
    return true
  }

/**
* Check the input data of the copy if it's right data, if the return is true,
* the data is correct, else the data is incorrect
* @param the copy information
* @return the result of the test: true/false
*/
  public boolean validateInput(Copy copy) {
    check the type of copy
    check the price of copy if it is a integer variable
    if one field is incorrect then
      return false
    return true
  }
}
