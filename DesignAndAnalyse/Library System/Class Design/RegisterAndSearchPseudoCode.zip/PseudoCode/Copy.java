class Copy {
  private String copyNumber;
  private String type;
  private int price;

  public String getCopyNumber() { return copyNumber; }
  public String getType() { return type; }
  public String getPrice() { return price; }

/**
* Display the copy's information
*/
  public void displayCopyInformation() {
    getCopyNumber() + getType() + getPrice();
  }
}
