class SearchController {

/**
* Implement the searching book
* @param the keyword that has already entered from the searching form
*/
  public void searchBook(String input) {
    Book book
    find the input in database
    if the data is found then
      call book.displayBookInformation
    else
      print the message "Not found"
  }
}
